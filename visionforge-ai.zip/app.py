from flask import Flask, request, jsonify, render_template
import openai
import os

app = Flask(__name__)
openai.api_key = os.getenv("OPENAI_API_KEY")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.get_json()
    idea = data.get("idea")

    if not idea:
        return jsonify({"result": "Please enter a business idea."})

    prompt = f"""
You are a sharp AI business mentor. Analyze the following business idea and:
1. Identify its strengths and weaknesses.
2. Suggest improvements and opportunities.
3. Predict how long it might take to succeed or fail.
4. Offer motivational advice.
5. Rate its uniqueness and viability from 1 to 10.

Business Idea:
"""{idea}"""
"""

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are a helpful and insightful startup analyst."},
                {"role": "user", "content": prompt}
            ],
            max_tokens=600,
            temperature=0.7
        )
        result = response['choices'][0]['message']['content']
        return jsonify({"result": result.strip()})

    except Exception as e:
        return jsonify({"result": f"Error: {str(e)}"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=81)